To compile the program, use the following compilation commands:
gcc -std=gnu99 -Wall -g -pthread -o keygen keygen.c
To run the program, execute the resulting executeable (keygen).

Makefile can also be used to compile, with the command 'make'